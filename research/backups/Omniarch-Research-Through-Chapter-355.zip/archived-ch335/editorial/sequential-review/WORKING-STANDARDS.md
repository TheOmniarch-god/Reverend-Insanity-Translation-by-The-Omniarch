# Working standards through Chapter335

Twelve working standards, not whole-novel certification or approval to edit.

## WS-01: Evidence and viewpoint

Label narrated action, testimony, inference, official record, recording, forecast and previous-life memory separately. A later explicit correction can overturn an earlier belief.

Established review method; not manuscript approval

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-02: Aperture quantities

Distinguish capacity, current reserves, essence quality and recovery rate. Use percentage points when the source measures changes against aperture capacity.

Strong working standard in covered mortal-aperture scenes

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-03: Revolution, stage and aptitude

Revolution, within-revolution stage, refined essence quality and aptitude are separate. Aptitude is not necessarily fixed for life.

Strong working distinction; mechanics remain revisable

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-04: Gu possession and control

Distinguish possession, refinement, borrowed permission, autonomous protection, recipe consumption, destruction and injury. Record acquisition and disposal events.

Strong working standard

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-05: Time units and interval scope

Keep时辰 and小时 distinct; conventionally one时辰 is abouttwo hours. Separate elapsed intervals, inclusive day labels, retrospective scenes and forecasts. Do not add an unexpressed next-day boundary.

Strong working unit distinction; calendar unresolved

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-06: Resources and storage

Separate asking price, estimate, accepted contract, payment, debt, repayment, stock and carrying capacity. Approximate figures stay approximate.

Established accounting method; balances locally incomplete

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-07: Ranges and physical staging

Preserve the source units and identify attack/reconnaissance mode and environment. Do not globally shrink geography or silently equatepaces and metres.

Conditional factual standards only

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-08: Ages and calendars

Separate cohort age, nominal/New Year age, birthday age, academic year and elapsed year. Do not invent birthdays or impose a calendar.

Open global reconciliation

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-09: Copy corrections and textual provenance

Exact local name/speaker slips may be strongly supported without settling global lore. Separate author-attributed notes, compiler speculation and narrative. Preserve original quotations and locations.

Local confidence can be high; all proposals still held

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-10: Completion and approval gates

Stabilising a working standard does not end sequential reading. Whole-novel confirmation requires review through 2334 and reconciliation of outstanding conflicts. No publication change is authorised merely by confidence or completed reading.

Standing workflow rule

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-11: Agreed working rendering of 人是万物之灵

Man is the most intelligent of all living things. Keep the repeated maxim recognisable across synopsis and narrative; do not imply different meanings through inconsistent paraphrase.

User-accepted working translation; not manuscript implementation approval

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.

## WS-12: Clan-specific titles and competitive offices

Keep 少主 distinct from 少族长. Do not equate every leader’s child with a designated heir. In Shang clan, separate ordinary children, ten selected junior-lord officeholders and one designated heir.

Working distinction strengthened; clan rules still require whole-novel review

Through335, retain provisional status. Distinguish source reading, translation equivalence, suspected inconsistency and chosen emendation. Batch016 fact-check addendum remains authoritative, with329p77 strengtheningSR136.